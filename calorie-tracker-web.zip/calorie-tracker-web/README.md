# Calorie Tracker Web (Personal)

A minimalist calorie tracking website (mobile-first), designed for personal use.

## Features
- Daily total + remaining calories
- Add meals (Breakfast/Lunch/Dinner/Snack)
- History viewer with day navigation and delete
- Settings: daily target calories
- Local-only storage via `localStorage`
- Export JSON / Reset data

## How to run (local)
Just open `index.html` in your browser.

## Deploy with GitHub Pages
1. Push this repo to GitHub
2. GitHub → Settings → Pages
3. Source: Deploy from a branch
4. Branch: `main` / folder: `/ (root)`
5. Save → wait a minute → open the URL shown

## Notes
- Data is saved in your browser. If you clear site data, logs are removed.
