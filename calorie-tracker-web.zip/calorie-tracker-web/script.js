/* Calorie Tracker (local-only)
   - Stores data in localStorage
   - Supports daily logs & history
*/

const STORAGE_KEY = "ctw:v1";

// ---------- Utilities ----------
const pad2 = (n) => String(n).padStart(2, "0");

function toDateKey(d) {
  const yyyy = d.getFullYear();
  const mm = pad2(d.getMonth() + 1);
  const dd = pad2(d.getDate());
  return `${yyyy}-${mm}-${dd}`;
}

function formatJP(d) {
  return `${d.getFullYear()}/${pad2(d.getMonth()+1)}/${pad2(d.getDate())}`;
}

function safeInt(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  return Math.max(0, Math.round(n));
}

function uid() {
  return Math.random().toString(36).slice(2, 10) + "-" + Date.now().toString(36);
}

// ---------- State ----------
function defaultState() {
  return {
    settings: { targetCalories: 2000 },
    days: {
      // "YYYY-MM-DD": [{ id, type, calories, note, ts }]
    },
  };
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    // minimal validation
    if (!parsed.settings || !parsed.days) return defaultState();
    if (!Number.isFinite(Number(parsed.settings.targetCalories))) parsed.settings.targetCalories = 2000;
    return parsed;
  } catch {
    return defaultState();
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

let state = loadState();

// ---------- UI elements ----------
const today = new Date();
let historyDate = new Date(today);

const elTodayLabel = document.getElementById("todayLabel");
const elTodayTotal = document.getElementById("todayTotal");
const elTargetCalories = document.getElementById("targetCalories");
const elRemainingCalories = document.getElementById("remainingCalories");
const elMealSummaryList = document.getElementById("mealSummaryList");

const addMealBtn = document.getElementById("addMealBtn");
const openHistoryBtn = document.getElementById("openHistory");

const mealModalBackdrop = document.getElementById("mealModalBackdrop");
const closeMealModal = document.getElementById("closeMealModal");
const cancelMealBtn = document.getElementById("cancelMealBtn");
const saveMealBtn = document.getElementById("saveMealBtn");
const calInput = document.getElementById("calInput");
const noteInput = document.getElementById("noteInput");

const segButtons = Array.from(document.querySelectorAll(".seg-btn"));
let selectedType = "breakfast";

const settingsBackdrop = document.getElementById("settingsBackdrop");
const openSettingsBtn = document.getElementById("openSettings");
const closeSettingsBtn = document.getElementById("closeSettings");
const cancelSettingsBtn = document.getElementById("cancelSettingsBtn");
const saveSettingsBtn = document.getElementById("saveSettingsBtn");
const targetInput = document.getElementById("targetInput");
const exportBtn = document.getElementById("exportBtn");
const resetBtn = document.getElementById("resetBtn");

const historyBackdrop = document.getElementById("historyBackdrop");
const closeHistoryBtn = document.getElementById("closeHistory");
const prevDayBtn = document.getElementById("prevDay");
const nextDayBtn = document.getElementById("nextDay");
const historyDateLabel = document.getElementById("historyDateLabel");
const historyList = document.getElementById("historyList");
const historyTotalEl = document.getElementById("historyTotal");
const historyTargetEl = document.getElementById("historyTarget");
const clearDayBtn = document.getElementById("clearDayBtn");

// ---------- Domain ----------
const TYPE_LABEL = {
  breakfast: "Breakfast",
  lunch: "Lunch",
  dinner: "Dinner",
  snack: "Snack",
};

function getMealsFor(dateKey) {
  return Array.isArray(state.days[dateKey]) ? state.days[dateKey] : [];
}

function setMealsFor(dateKey, meals) {
  state.days[dateKey] = meals;
}

function dayTotal(dateKey) {
  return getMealsFor(dateKey).reduce((sum, m) => sum + (Number(m.calories) || 0), 0);
}

function typeSum(dateKey, type) {
  return getMealsFor(dateKey)
    .filter(m => m.type === type)
    .reduce((sum, m) => sum + (Number(m.calories) || 0), 0);
}

// ---------- Render ----------
function renderToday() {
  const todayKey = toDateKey(today);
  const target = Number(state.settings.targetCalories) || 2000;
  const total = dayTotal(todayKey);
  const remaining = target - total;

  elTodayLabel.textContent = formatJP(today);
  elTodayTotal.textContent = total.toLocaleString("ja-JP");
  elTargetCalories.textContent = target.toLocaleString("ja-JP");
  elRemainingCalories.textContent = remaining.toLocaleString("ja-JP");

  elMealSummaryList.innerHTML = "";
  const types = ["breakfast","lunch","dinner","snack"];
  for (const t of types) {
    const s = typeSum(todayKey, t);
    const li = document.createElement("li");
    li.className = "meal-row";
    li.innerHTML = `
      <div class="meal-left">
        <span class="dot"></span>
        <div>
          <div class="meal-name">${TYPE_LABEL[t]}</div>
          <div class="meal-sub">${s === 0 ? "No log yet" : "Logged"}</div>
        </div>
      </div>
      <div class="meal-kcal">${s.toLocaleString("ja-JP")} kcal</div>
    `;
    elMealSummaryList.appendChild(li);
  }
}

function renderHistory() {
  const key = toDateKey(historyDate);
  const target = Number(state.settings.targetCalories) || 2000;
  const meals = getMealsFor(key).slice().sort((a,b) => (b.ts||0) - (a.ts||0));
  const total = dayTotal(key);

  historyDateLabel.textContent = formatJP(historyDate);
  historyTotalEl.textContent = total.toLocaleString("ja-JP");
  historyTargetEl.textContent = target.toLocaleString("ja-JP");

  historyList.innerHTML = "";
  if (meals.length === 0) {
    const empty = document.createElement("li");
    empty.className = "hist-row";
    empty.innerHTML = `<div class="hist-left"><div class="hist-title">No meals logged</div><div class="hist-note">Add meals from the main screen</div></div>`;
    historyList.appendChild(empty);
    return;
  }

  for (const m of meals) {
    const row = document.createElement("li");
    row.className = "hist-row";
    const note = (m.note || "").trim();
    row.innerHTML = `
      <div class="hist-left">
        <div class="hist-title">${TYPE_LABEL[m.type] || "Meal"} · ${Number(m.calories).toLocaleString("ja-JP")} kcal</div>
        ${note ? `<div class="hist-note">${escapeHtml(note)}</div>` : `<div class="hist-note">—</div>`}
      </div>
      <button class="small-btn danger" data-id="${m.id}" title="Delete">Del</button>
    `;
    historyList.appendChild(row);
  }

  // bind delete buttons
  historyList.querySelectorAll("button[data-id]").forEach(btn => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-id");
      const next = getMealsFor(key).filter(x => x.id !== id);
      setMealsFor(key, next);
      saveState();
      renderToday();
      renderHistory();
    });
  });
}

function escapeHtml(s){
  return s
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

// ---------- Modals ----------
function openModal(backdropEl) {
  backdropEl.classList.add("is-open");
  backdropEl.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}
function closeModal(backdropEl) {
  backdropEl.classList.remove("is-open");
  backdropEl.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function resetMealForm() {
  selectedType = "breakfast";
  segButtons.forEach(b => b.classList.toggle("is-active", b.dataset.type === selectedType));
  calInput.value = "";
  noteInput.value = "";
}

// ---------- Events: Add Meal ----------
segButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    selectedType = btn.dataset.type;
    segButtons.forEach(b => b.classList.toggle("is-active", b.dataset.type === selectedType));
  });
});

addMealBtn.addEventListener("click", () => {
  resetMealForm();
  openModal(mealModalBackdrop);
  setTimeout(() => calInput.focus(), 50);
});

function closeMeal() { closeModal(mealModalBackdrop); }

closeMealModal.addEventListener("click", closeMeal);
cancelMealBtn.addEventListener("click", closeMeal);
mealModalBackdrop.addEventListener("click", (e) => {
  if (e.target === mealModalBackdrop) closeMeal();
});

saveMealBtn.addEventListener("click", () => {
  const cal = safeInt(calInput.value);
  if (cal === null) {
    alert("カロリーを数字で入力してください（例: 450）");
    calInput.focus();
    return;
  }
  const note = (noteInput.value || "").trim();

  const key = toDateKey(today);
  const meals = getMealsFor(key);
  meals.push({
    id: uid(),
    type: selectedType,
    calories: cal,
    note,
    ts: Date.now(),
  });
  setMealsFor(key, meals);
  saveState();

  closeMeal();
  renderToday();
});

// Enter key to save (when focused on calories)
calInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveMealBtn.click();
});

// ---------- History ----------
openHistoryBtn.addEventListener("click", () => {
  historyDate = new Date(today);
  renderHistory();
  openModal(historyBackdrop);
});
closeHistoryBtn.addEventListener("click", () => closeModal(historyBackdrop));
historyBackdrop.addEventListener("click", (e) => {
  if (e.target === historyBackdrop) closeModal(historyBackdrop);
});
prevDayBtn.addEventListener("click", () => {
  historyDate.setDate(historyDate.getDate() - 1);
  renderHistory();
});
nextDayBtn.addEventListener("click", () => {
  historyDate.setDate(historyDate.getDate() + 1);
  renderHistory();
});
clearDayBtn.addEventListener("click", () => {
  const key = toDateKey(historyDate);
  if (!confirm(`${formatJP(historyDate)} の記録を削除しますか？`)) return;
  delete state.days[key];
  saveState();
  renderToday();
  renderHistory();
});

// ---------- Settings ----------
openSettingsBtn.addEventListener("click", () => {
  targetInput.value = String(Number(state.settings.targetCalories) || 2000);
  openModal(settingsBackdrop);
  setTimeout(() => targetInput.focus(), 50);
});
function closeSettings(){ closeModal(settingsBackdrop); }

closeSettingsBtn.addEventListener("click", closeSettings);
cancelSettingsBtn.addEventListener("click", closeSettings);
settingsBackdrop.addEventListener("click", (e) => {
  if (e.target === settingsBackdrop) closeSettings();
});

saveSettingsBtn.addEventListener("click", () => {
  const t = safeInt(targetInput.value);
  if (t === null || t < 200) {
    alert("目標カロリーを数字で入力してください（例: 2000）");
    targetInput.focus();
    return;
  }
  state.settings.targetCalories = t;
  saveState();
  closeSettings();
  renderToday();
  renderHistory();
});

exportBtn.addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `calorie-tracker-export-${toDateKey(new Date())}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
});

resetBtn.addEventListener("click", () => {
  if (!confirm("全データをリセットしますか？（元に戻せません）")) return;
  state = defaultState();
  saveState();
  closeSettings();
  renderToday();
});

// ---------- Init ----------
renderToday();
